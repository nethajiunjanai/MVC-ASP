﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Controllers
{
    public class htmluihelper6Controller : Controller
    {
        //
        // GET: /htmluihelper6/

        public ActionResult acceptinfo()
        {
            return View();
        }

    }
}
