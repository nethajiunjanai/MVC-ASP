﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class displayproductController : Controller
    {
        //
        // GET: /displayproduct/

        public ActionResult showproduct()
        {
            product p = new product() { productid = 1, productname = "kit" };
            return View(p);
        }

        public ActionResult storedata()
        {
            TempData["number"] = 10;
          //  return View("displaydata");
          return  RedirectToAction("displaydata");
        }
        public ActionResult displaydata()
        {
            return View();
        }
        
    }
}
