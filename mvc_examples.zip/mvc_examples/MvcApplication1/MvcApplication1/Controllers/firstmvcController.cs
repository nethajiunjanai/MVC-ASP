﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication1.Controllers
{
    public class firstmvcController : Controller
    {
        //
        // GET: /firstmvc/

        public ActionResult showdata()
        //showdata is the view name
        {
            return View();
        }

        public ActionResult showhtmldata()
        {
            return View();
        }

        public ActionResult showaspxdata()
        {
            return View();
        }

        public ActionResult manipulatehtmlarray()
        {
            return View();
        }

        public ActionResult manipulatecollection()
        {
            return View();
        }

        public ActionResult functioncallinghtml()
        { 
            return View();
        }

        public ActionResult functioncallingaspx()
        {
            return View();

        }

        public ActionResult manipulateerrorhtml()
        {
            return View();

        }
        public ActionResult showformhtml()
        {
            return View();
        }
    }
}
