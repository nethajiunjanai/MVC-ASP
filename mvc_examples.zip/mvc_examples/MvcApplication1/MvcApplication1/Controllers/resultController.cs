﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;

namespace MvcApplication1.Controllers
{
    public class resultController : Controller
    {
        //
        // GET: /result/

        public ActionResult Index()
        {
            return View();
        }
        public string showstring()
        {
            return "my batch code is chn17id001";
        }

        public int showint()
        {
            return 3;
        }

        public ContentResult showcontent()
        {
            return Content("hello","text/plain",Encoding.UTF8);
        }
        
        //json
        public class user
        {
            public int userid { get; set; }
            public string username{get;set;}
        }

        public JsonResult showjson()
        {
            user u = new user() {userid=1,username="red" };
            return Json(u,JsonRequestBehavior.AllowGet);
        }


        public ActionResult showviewdata()
        {
            
            //ViewData["alphabets"]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var std = new List<string> { "Apple", "Orange", "Papaya" };
            //ViewData["fruits"] = std;
            ViewBag.fruits = std;
            return View();
        }
        
        
    }
}

