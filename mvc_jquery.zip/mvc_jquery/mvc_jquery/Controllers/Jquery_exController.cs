﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_jquery.Models;

namespace mvc_jquery.Controllers
{
    public class Jquery_exController : Controller
    {
        //
        // GET: /Jquery_ex/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult datepicker_ex()
        {
            dreamhomeEntities dh = new dreamhomeEntities();
          //  List<string> lin = from s in dh.staffs select s.oPosition.Distinct().ToList();
            List<string> li = dh.staffs.Select(m => m.oPosition).Distinct().ToList();

            return View(li);

        }

        public ActionResult selectcity()
        {
            return View();
        }

       
        //using json
        public JsonResult showname( string nm)
        {
            dreamhomeEntities dh=new dreamhomeEntities();
            var res=dh.tblStudents.Where(c=>c.Name.Contains(nm)).Select(c=>c.Name);
          //  var ne = from s in dh.tblStudents where s.Name.Contains(nm) select s.Name;
            return Json(res);
        }
        public ActionResult autocompleteex()
        {
            return View();
        }
    }
}
