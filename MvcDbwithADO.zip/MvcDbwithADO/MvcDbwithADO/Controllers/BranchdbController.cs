﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcDbwithADO.Models;
using MvcDbwithADO.Repository;

namespace MvcDbwithADO.Controllers
{
    public class BranchdbController : Controller
    {
        //
        // GET: /Branchdb/
        //first create class model
        //second connection string will b gvn in web.config
        //add repository function folder for implementation
        public ActionResult get_all_branches()
        {

            branch_repository br = new branch_repository();
            return View(br.get_all_branch());
        }

        public ActionResult acceptbranch()
        {
            return View();
        }

        public ActionResult savebranch(branch b)
        {
            branch_repository bran_rep = new branch_repository();
            if (bran_rep.insert_branch(b)==true)
            {
                //ViewBag.information="Records inserted succesfully";
                return RedirectToAction("get_all_branches");
            }
            else
            {
                ViewBag.information="Error occured";
                return View();
             }
            
           
        }

        public ActionResult accept_delete_branch(branch b)
        {
            if (Request.RequestType != "POST")
            { return View(); }
            else
            {
                branch_repository br = new branch_repository();
                if (br.delete_branch(b.branchno) == true)
                {
                    ViewBag.information = "Records deleted successfully";
                }
                else
                {
                    ViewBag.information = "Error occured while deleting";
                }

                return View();
            }
        }

        public ActionResult delete_direct(string s)
        {
            //if (Request.RequestType != "POST")
            //{
            //    return View();
            //}
            //else
            {
                branch_repository br = new branch_repository();
                if (br.delete_branch(s) == true)
                {
                    //ViewBag.information = "Records deleted successfully";
                    return RedirectToAction("get_all_branches");
                }
                else
                {
                  //  ViewBag.information = "Error occured while deleting";
                    return View();
                }

                
            }
        }
        public ActionResult get_branch(string brno)
            
        { 
            branch_repository br=new branch_repository();
            branch b = br.show_branch(brno);
            return View(b);
        }

        public ActionResult update_branch(string brno)

        {
            branch_repository br = new branch_repository();
            branch b = br.show_branch(brno);
            return View(b);
        }
       [HttpPost]
        public ActionResult update_branch(branch b)
        {

            branch_repository br = new branch_repository();
            if (br.update_branch(b))
                return RedirectToAction("get_all_branches");
            else
            return View();
        }
    }
}
