﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcDbwithADO.Models
{
    public class branch
    {
        [Key]
        public string branchno { get; set; }

        public string street { get; set; }
        public string city { get; set; }
        public string postcode { get; set; }
    }
}