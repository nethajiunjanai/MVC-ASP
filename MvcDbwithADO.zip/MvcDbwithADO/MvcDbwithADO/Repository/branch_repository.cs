﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using MvcDbwithADO.Models;
//add namespaces 
namespace MvcDbwithADO.Repository
{
    public class branch_repository
    {
        SqlConnection con;
        SqlCommand cmd;

        private void connect()
        {
            string constring = ConfigurationManager.ConnectionStrings["dream"].ConnectionString;
            con = new SqlConnection(constring);  
        }

        public List<branch> get_all_branch()
        {
            connect();
            List<branch> bh = new List<branch>();
            string qry = "select * from branch";
            cmd = new SqlCommand(qry, con);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                bh.Add(new branch()
                                   {branchno=dr[0].ToString(),
                                   street=Convert.ToString(dr[1]),
                                   city=Convert.ToString(dr[2]),
                                   postcode=Convert.ToString(dr[3])
                                   });
            }

            return bh;
        }

        public bool insert_branch(branch bn)
        {
            connect();
            string qry = "insert into branch values(@bno,@strt,@city,@postcode)";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;

            cmd.Parameters.AddWithValue("@bno", bn.branchno);
            cmd.Parameters.AddWithValue("@strt",bn.street);
            cmd.Parameters.AddWithValue("@city",bn.city);
            cmd.Parameters.AddWithValue("@postcode",bn.postcode);
            
            con.Open();

            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
       }

        public bool delete_branch(string bn)
        {
            connect();
            
            string qry = "delete from branch where branchNo=@brno";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;

            cmd.Parameters.AddWithValue("@brno", bn);
            con.Open();

            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        public branch show_branch(string brno)

        {
            connect();
            con.Open();
            branch br = new branch();
            string qry = "select * from branch where branchno=@brno";
            cmd=con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            cmd.Parameters.AddWithValue("@brno", brno);
           // con.Open();
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                br.branchno = dr[0].ToString();
                br.street= dr[1].ToString();
                br.city = dr[2].ToString();
                br.postcode = dr[3].ToString();             
            }
            return br;
            
        }

        public bool update_branch(branch b)
        {
            connect();
            con.Open();
            string qry = "update branch set street=@street,city=@city,postcode=@postcode where branchno=@branchno";
            cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            cmd.Parameters.AddWithValue("@branchno", b.branchno);
            cmd.Parameters.AddWithValue("@street", b.street);
            cmd.Parameters.AddWithValue("@city", b.city);
            cmd.Parameters.AddWithValue("@postcode", b.postcode);
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                return true;
            }
            else
            { return false;
            }
        }

    }
}