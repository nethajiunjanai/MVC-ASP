﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Models
{
    public class employee
    {
        public int eid { get; set; }
        public string ename { get; set; }
        public double salary { get; set; }
    }
}