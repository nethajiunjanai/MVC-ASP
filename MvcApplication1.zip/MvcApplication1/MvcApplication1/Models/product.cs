﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Models
{
    public class product
    {
        public int productid { get; set; }
        public string productname { get; set; }
    }
}