﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;
using MvcApplication1.Controllers;

namespace MvcApplication1.Controllers
{
    public class htmlformController4 : Controller
    {
        //
        // GET: /htmlform/

        public ActionResult acceptemp()
        {
            return View();
        }
//create class in model and use that class
        public ActionResult displayemp()
        {
            employee e = new employee();
            e.eid = int.Parse(Request.Form["txteid"]);
            e.ename = Request.Form["txtename"];
            e.salary = double.Parse(Request.Form["txtesal"]);

            return View(e);

        }
    }
}
