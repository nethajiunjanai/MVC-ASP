﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Controllers;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class htmlformcollection5Controller : Controller
    {
        //
        // GET: /htmlformcollection/

        public ActionResult addemp()
        {
            return View();
        }
        //connecting one view to another
        //create view with st.model
        public ActionResult printemp(FormCollection fc)
        {
            employee e = new employee();
            e.eid = int.Parse(fc["eid"]);
            e.ename = fc["ename"];
            e.salary = double.Parse(fc["esal"]);
            return View(e);
        }

    }
}
