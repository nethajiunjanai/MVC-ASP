﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_eg_first.Controllers
{
    public class FirstMVCController : Controller
    {
        //
        // GET: /FirstMVC/

        public ActionResult show_data()
            
            //show_data() is the view name

        {
            return View();
        }

        public ActionResult show_html_data()
        {
            return View();
        }

        public ActionResult show_aspx_data()
        {
            return View();
        }
        public ActionResult manipulate_html_array()
        {
            return View();
        }

        public ActionResult manipulate_collection_html()
        {
            return View();
        }

        public ActionResult func_calling_html()
        {
            return View();
        }
        public ActionResult except()
        {
            return View();
        }

        public ActionResult show_form_html()
        {
            return View();
        }

    }
}
