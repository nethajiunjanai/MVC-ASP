﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;

namespace Mvc_eg_first.Controllers
{
    public class ResultController : Controller
    {
        //
        // GET: /Result/

        public ActionResult Index()
        {
            return View();
        }

        public string show_string()
        {
            return "My Batch ID is CHN17ID001";
        }

        public int show_int()
        {
            return 3;
        }

        public ContentResult show_content()
        {
            return Content("hi guys","text/plain",Encoding.UTF8);
        }

        public class user
        {
            public int userid { get;set;}
            public string username{get;set;}
        }

        public JsonResult show_json()
        {
            user u = new user() {userid=1,username="Raina"};
            return Json(u,JsonRequestBehavior.AllowGet);
        }

        public ActionResult show_viewdata()
        {
            //ViewData["alphabets"]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var std = new List<string> { "Apple", "Orange", "Papaya" };
            //ViewData["fruits"] = std;


            ViewBag.fruits=std;
            return View();
        } 


    }
}
