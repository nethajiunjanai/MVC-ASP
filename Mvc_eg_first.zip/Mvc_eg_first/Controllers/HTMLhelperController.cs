﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_eg_first.Controllers
{
    public class HTMLhelperController : Controller
    {
        //
        // GET: /HTMLhelper/

        public ActionResult AcceptInfo()
        {
            return View();
        }

    }
}
