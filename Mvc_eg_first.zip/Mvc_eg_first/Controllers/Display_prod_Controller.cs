﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_eg_first.Models;

namespace Mvc_eg_first.Controllers
{
    public class Display_prod_Controller : Controller
    {
        //
        // GET: /Display_prod_/

        public ActionResult show_product()
        {
            product p = new product() { prod_id = 1, prod_name = "Biscuit" };
            return View(p);
        }

        public ActionResult store_data()
        {
           
             TempData["number"]=10;
             return View("display_data");


        }
        public ActionResult session_data()
        {

            Session["number"] = 10;
            return View("display1_data");


        }
        public ActionResult display_data()
        {
            return View();
        }

        public ActionResult display1_data()
        {
            return View();
        }

        
    }
}
