﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_eg_first.Models;

namespace Mvc_eg_first.Controllers
{
    public class htmlUIempController : Controller
    {
        //
        // GET: /htmlUIemp/

        public ActionResult reademp()
        {
            return View();
        }
        public ActionResult writeemp()
        {
            mvc.Employee e = new mvc.Employee();
            e.eid = Int32.Parse(Request.Form["eid"]);
            e.ename = Request.Form["ename"];
            e.salary = double.Parse(Request.Form["salary"]);
            return View(e);
        } 

        public ActionResult storemodelemp()
        {
            return View();
        }

        public ActionResult displaymodelemp()
        {
            return View();
        }
    }
}
