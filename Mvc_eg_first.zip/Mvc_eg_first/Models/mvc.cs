﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_eg_first.Models
{
    public class mvc
    {
        public class Employee
        {
            public int eid { get; set; }
            public string ename { get; set; }
            public double salary { get; set; }
        } 
    }
}