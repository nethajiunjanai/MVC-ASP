﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_eg_first.Models
{
    public class product
    {
        public int prod_id{ get; set;}
        public string prod_name { get; set; }
    }
}