﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcBasic.Models
{
    public class Employee
    {
        //creation of annotations

        [Required(ErrorMessage="Employee Id should not be blank")]
        [Key]
        public int eid { get; set; }

        [Required(ErrorMessage="Name should not be blank")]
        //[DataType(DataType.Text,ErrorMessage="Enter the perfect datatype")]
        public string ename { get; set; }

        [Required(ErrorMessage = "Employee salary should not be blank")]
        [Range(10000.00,20000.00)]
        public double salary { get; set; }
    }
}