﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcBasic.Models;

namespace MvcBasic.Controllers
{
    public class validateEmpController : Controller
    {
        //
        // GET: /validateEmp/
        //order
        //employee class
        //view for acceptemp
        //view for printemp
        public ActionResult acceptemp()
        {
            return View();
        }

        public ActionResult printemp(Employee e)
        {
             return View();
        }


    }
}
