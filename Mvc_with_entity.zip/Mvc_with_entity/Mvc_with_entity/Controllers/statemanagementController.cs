﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_with_entity.Models;

namespace Mvc_with_entity.Controllers
{
    public class statemanagementController : Controller
    {
        //
        // GET: /statemanagement/

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection fc,student s)
        {
            Session["info"] = fc["nationality"];
            return RedirectToAction("show",s);
        }

        public ActionResult show(student s)
        {
            return View(s);
        }
    }
}
