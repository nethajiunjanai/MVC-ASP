﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_with_entity.Controllers
{
    public class querystringController : Controller
    {
        //
        // GET: /querystring/

        public ActionResult Index(string id,string ename,string dname)
        {
            string res = "ename= " + ename + " departmentname= " + dname;
            return Content(res);
          //  return View();
        }

    }
}
