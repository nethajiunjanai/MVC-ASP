﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace Mvc_with_entity.Controllers
{
    [HandleError]
    public class dreamhomeController : Controller
    {
        //
        // GET: /dreamhome/

        public ActionResult get_all_branch()
        {
            dreamhomeEntities dh = new dreamhomeEntities();
            //List<branch> br = (from d in dh.branches select d).ToList();
            List<branch> br = (from d in dh.branches select d).ToList<branch>();
            return View(br);
        }

        public ActionResult acceptbranch()
        {
            return View();
        }
        public ActionResult savebranch(branch b)
        {
            dreamhomeEntities dh = new dreamhomeEntities();
            dh.branches.Add(b);
            dh.SaveChanges();
            return RedirectToAction("get_all_branch");
        }

        public ActionResult get_branch(string brno)
        {
            dreamhomeEntities dh = new dreamhomeEntities();
            branch b = dh.branches.Find(brno);

            return View(b);
        }

         public ActionResult delete_branch(string brno)
        {
            dreamhomeEntities dh = new dreamhomeEntities();
            branch b = dh.branches.Find(brno);
            dh.branches.Remove(b);
            dh.SaveChanges();
            return RedirectToAction("get_all_branch");
          //  return View();     
        }

         public ActionResult update_branch(string brno)
         {
             dreamhomeEntities dh = new dreamhomeEntities();
             branch b = dh.branches.Find(brno);
             return View(b);
         }
         [HttpPost]
         public ActionResult update_branch(branch b)
         {

             dreamhomeEntities dh = new dreamhomeEntities();
             branch br = dh.branches.Find(b.branchNo);
             br.branchNo = b.branchNo;
             br.street = b.street;
             br.city = b.city;
             br.postcode = b.postcode;
           //  dh.branches.Add(br);
             dh.SaveChanges();
             return RedirectToAction("get_all_branch");
         }


        //auto generarated
        //scaffolding
         public ActionResult delete(string brno)
         {

             dreamhomeEntities dh = new dreamhomeEntities();
             branch b = dh.branches.Find(brno);
             dh.branches.Remove(b);
             dh.SaveChanges();
             return RedirectToAction("get_all_branch");
            // return View();
         }

       
         public ActionResult partial_view()
         {
             return PartialView();
         }
    }
}
