﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_with_entity.Models
{
    public class student
    {
        public int studentid { get; set; }
        public string studentname { get; set; }
    }
}