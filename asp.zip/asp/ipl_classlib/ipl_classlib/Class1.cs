﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;


namespace ipl_classlib
{
    public class ipllib
    {
        public int insertmatch(string team1, string team2, string result, string pom)
        {

            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string qry = "insert into add1 values (@team1,@team2,@result,@pom)";


            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);

            SqlParameter p1 = cmd.Parameters.Add("@team1", SqlDbType.VarChar, 20);
            p1.Value = team1;

            SqlParameter p2 = cmd.Parameters.Add("@team2", SqlDbType.VarChar, 20);
            p2.Value = team2;

            SqlParameter p3 = cmd.Parameters.Add("@result", SqlDbType.VarChar, 20);
            p3.Value = result;

            SqlParameter p4 = cmd.Parameters.Add("@pom", SqlDbType.VarChar, 20);
            p4.Value = pom;
            return cmd.ExecuteNonQuery();
        }

        public DataSet showmatches()
        {
            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string qry = "select team1,team2,result,pom from add1";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry,con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }

        public DataSet showteams()
        {
            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string qry = "select teamid,teamname from teams";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        public int validid(string user,string password)
        { 
            
            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string qry = "select count(*) from userpass where userid=@user and pass=@password";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlParameter p1 = cmd.Parameters.Add("@user",SqlDbType.VarChar,20);
            p1.Value = user;
            SqlParameter p2 = cmd.Parameters.Add("@password", SqlDbType.VarChar, 20);
            p2.Value = password;
            object o = cmd.ExecuteScalar();
            int i = (int)o;
            return i;
        }

        public int signup(string user, string passw)
        {
            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string qry = "insert into userpass values (@user,@pass)";


            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);

            SqlParameter p1 = cmd.Parameters.Add("@user", SqlDbType.VarChar, 20);
            p1.Value = user;

            SqlParameter p2 = cmd.Parameters.Add("@pass", SqlDbType.VarChar, 20);
            p2.Value = passw;
            return cmd.ExecuteNonQuery();
        }
    }
}
