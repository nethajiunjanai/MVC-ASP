﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//using System.Threading.Tasks;

namespace ipl_library
{
  public class ipllibrary
    {
      public int insert_branch(string team1,string team2,string result,string pom)
      {
          string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
          string qry = "insert into add values(@team1,@team2,@result,@pom)";
          SqlConnection con = new SqlConnection(constring);
          SqlCommand cmd = new SqlCommand(qry, con);
          SqlParameter p1 = cmd.Parameters.Add("@team1", SqlDbType.VarChar, 20);
          p1.Value = team1;
          SqlParameter p2 = cmd.Parameters.Add("@team2", SqlDbType.VarChar, 20);
          p2.Value = team2;
          SqlParameter p3 = cmd.Parameters.Add("@team2", SqlDbType.VarChar, 20);
          p3.Value =result;
          SqlParameter p4 = cmd.Parameters.Add("@team2", SqlDbType.VarChar, 20);
          p4.Value =pom;
          return cmd.ExecuteNonQuery();        
      }
    }
}
