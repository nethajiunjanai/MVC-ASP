﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp.net
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           // Response.Write("my first asp.net program");
           // Response.Redirect("webform2.aspx");   
            if (TextBox1.Text.Length == 0)
            {
                Label1.Visible = true;
            }
            else { Label1.Visible = false; }
            
            if (TextBox2.Text.Length == 0)
            {
                Label2.Visible = true;
            }
            else { Label2.Visible = false; }
            
           
            if((TextBox1.Text.Length > 0)&&(TextBox2.Text.Length > 0))
            {
                Response.Redirect("webform2.aspx"); 
            }
        }
    }
}