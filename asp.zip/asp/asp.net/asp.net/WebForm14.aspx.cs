﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp.net
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            product p = new product();
            p.prodid = int.Parse(TextBox1.Text);
            p.prodname = TextBox2.Text;
            Session["prod_det"] = p;
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //session is now stored in server
            //cookies store in client side
            
            product target = (product)(Session["prod_det"]);
            TextBox1.Text = target.prodid.ToString();
            TextBox2.Text = target.prodname.ToString();
        }
    }

    [Serializable]
    public class product
    {
        public int prodid;
        public string prodname;
    }
}