﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.Entity;
using System.Data;
using System.Configuration;
namespace asp.net
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
            String constring = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
            string qry = "select * from branch";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            //mandatory to give databind to display output
            GridView1.DataBind();
        }
    }
}