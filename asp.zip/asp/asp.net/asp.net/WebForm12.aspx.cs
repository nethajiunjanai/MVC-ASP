﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//session management
namespace asp.net
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //for control state explanation
            //check label2 properties--enable viewstate
            //enable view state can be set in three ways--1.web.config--pages--add enableviewstate 2.source of design 3.property
            Label1.Text = "thanks";
            Label2.Text = "thanks";
        }
    }
}