﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//exception handling in asp.net
namespace asp.net
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ////using try catch block
            //try
            //{
            //    int val1 = int.Parse(TextBox1.Text);
            //    int val2 = int.Parse(TextBox2.Text);
            //    int res = val1 / val2;
            //    Response.Write(res);
            //}
            //catch(Exception d)
            //    {
            //      //  Response.Write("invalid");
            //       Response.Write(d.Message.ToString());
                       
            //    }

            //server.getlasterror method
            //check global.aspx 
            int val1 = int.Parse(TextBox1.Text);
            int val2 = int.Parse(TextBox2.Text);
            int res = val1 / val2;
            Response.Write(res);
        }
        //protected void Page_Error(object sender, EventArgs e)
        //{
        //   Response.Write(Server.GetLastError().Message.ToString());
        //   Server.ClearError();

        //}
    }
}