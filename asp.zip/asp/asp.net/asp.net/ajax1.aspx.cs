﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp.net
{
    public partial class ajax1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          if(!Page.IsPostBack)
            {
                DropDownList1.Items.Add("--select--");
                DropDownList1.Items.Add("andhra");
                 DropDownList1.Items.Add("Tamilnadu");
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
             DropDownList2.Items.Clear();
            if (DropDownList1.Text == "Tamilnadu")
            {
                DropDownList2.Items.Add("--select--");
                DropDownList2.Items.Add("chennai");
                DropDownList2.Items.Add("madurai");
            }
            else if (DropDownList1.Text == "andhra")
            {
                DropDownList2.Items.Add("--select--");
                DropDownList2.Items.Add("kadapa");
                DropDownList2.Items.Add("Tirupathi");
            }
        }
    }
}