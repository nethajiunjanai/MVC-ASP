﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace asp.net
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                displaydata();
            }

        }
        public void displaydata()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "select branchNo,street,city,postcode from branch";
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);                                               
            GridView1.DataSource = ds;
            GridView1.DataBind();
            
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
      
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            displaydata();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            //-1 dont do any changes
             displaydata();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //e.rowindex--e refers which row is chosen
            string bno = GridView1.Rows[e.RowIndex].Cells[2].Text;
            string del_qry = "delete from branch where branchNo=@branchNo";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
         //   SqlCommand cmd = new SqlCommand(del_qry, con);
            SqlCommand cmd=con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = del_qry;
            SqlParameter p1=cmd.Parameters.Add("@branchNo",SqlDbType.VarChar,20);
            p1.Value = bno;
            int total = cmd.ExecuteNonQuery();


            if (total == 1)
            {
                ClientScript.RegisterStartupScript(GetType(), "success", "<Script>alert('deleted successfully')</Script>");
            }
            displaydata();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string bno = ((TextBox)(GridView1.Rows[e.RowIndex].Cells[2].Controls[0])).Text;
            string streets = ((TextBox)(GridView1.Rows[e.RowIndex].Cells[3].Controls[0])).Text;
            string cty = ((TextBox)(GridView1.Rows[e.RowIndex].Cells[4].Controls[0])).Text;
            string pcode = ((TextBox)(GridView1.Rows[e.RowIndex].Cells[5].Controls[0])).Text;
            string ins_qry = "update branch set branchNo=@branchNo,street=@street,city=@city,postcode=@postcode where branchNo=@branchNo";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ins_qry;
            SqlParameter p1 = cmd.Parameters.Add("@branchNo", SqlDbType.VarChar, 20);
            p1.Value = bno;
            SqlParameter p2 = cmd.Parameters.Add("@street", SqlDbType.VarChar, 20);
            p2.Value = streets;
            SqlParameter p3 = cmd.Parameters.Add("@city", SqlDbType.VarChar, 20);
            p3.Value = cty;
            SqlParameter p4 = cmd.Parameters.Add("@postcode", SqlDbType.VarChar, 20);
            p4.Value = pcode;

            int total = cmd.ExecuteNonQuery();


            if (total == 1)
            {
                ClientScript.RegisterStartupScript(GetType(), "success", "<Script>alert('updated successfully')</Script>");
            }
            displaydata();
        }
    }
}