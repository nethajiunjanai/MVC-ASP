﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp.net
{
    public partial class WebForm15 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           // double dollar = double.Parse(TextBox1.Text);
           // TextBox2.Text = (dollar * 67.2).ToString();
            ServiceReference1.Service1SoapClient so = new ServiceReference1.Service1SoapClient();
            int dollarvalue = Int32.Parse(TextBox1.Text);
            double rsvalue = so.dollartors(dollarvalue);
            TextBox2.Text = rsvalue.ToString();

        }
    }
}