﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//create cookies
namespace asp.net
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //cookies are generated in server side
            HttpCookie hc = new HttpCookie("data");
            hc["uname"] = TextBox1.Text;
            hc["age"] = TextBox2.Text;
            hc.Expires.AddHours(2);
            Response.Cookies.Add(hc);
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //to retrieve from client side
            HttpCookie hp = Request.Cookies["data"];
            if (hp != null)
            {
                TextBox1.Text = hp["uname"].ToString();
                TextBox2.Text = hp["age"].ToString();
            }

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            //to show in next page
            //we are using show.aspx file
            //the below query string format will transfer data
            Response.Redirect("show.aspx?uname=" + TextBox1.Text + "&age=" + TextBox2.Text);
        }
    }
}