﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp.net
{
    public partial class ajax3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(5000);
            int v1 = int.Parse(TextBox1.Text);
            int v2 = int.Parse(TextBox2.Text);
            int v3 = v1 + v2;
            Label3.Text = v3.ToString();
        }
    }
}