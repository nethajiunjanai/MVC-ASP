﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using asp.net;

namespace asp.net
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AuthConfig.RegisterOpenAuth();
            //application variable
            Application["hitcount"] = 0;
        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs
            System.Web.HttpContext ctx = HttpContext.Current;
            //Response.Write(ctx.Server.GetLastError().Message.ToString());
            Response.Write(ctx.Server.GetLastError().InnerException.Message.ToString());
            ctx.Server.ClearError();

        }
        void Session_Start(object sender, EventArgs e)
        {
            Application.Lock();
            Application["hitcount"] = (int)Application["hitcount"] + 1;
            Application.UnLock();
        }
    }
}
