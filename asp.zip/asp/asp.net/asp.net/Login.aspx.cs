﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;
//authentication authorization
//check changes in authentication and authorization in global.aspx
namespace asp.net
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          //  string id = TextBox1.Text;
          //  string pw = TextBox2.Text;
            string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
            string qry = "select count(*) from userdata where userid=@userid and pwd=@pwd";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
         //   SqlCommand cmd = new SqlCommand(qry, con);
            SqlParameter p1 = cmd.Parameters.Add("@userid", SqlDbType.VarChar, 20);
            p1.Value = TextBox1.Text;
            SqlParameter p2 = cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 20);
            p2.Value = TextBox2.Text;
            int res = (int)cmd.ExecuteScalar();
            
            if (res==1)
            {
                FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, true);
               
                Response.Redirect("Welcome.aspx");
            }
            else
            {
                Response.Write("invalid username or password");
            }

        }
    }
}