﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace asp.net
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //ispostback is used to check whether user is connected or not
            if (Page.IsPostBack == true)
            {
                Response.Write("already connected user");
            }
            else
            {
                Response.Write("welcome user");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}