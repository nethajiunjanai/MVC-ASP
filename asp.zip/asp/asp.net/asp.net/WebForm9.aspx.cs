﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace asp.net
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        string constring = "server=pc251447;database=chn17id001;integrated security=false;user id=sa;password=password-1";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                showdata();
            }
        }
        public void showdata()
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "select userid,pwd,status,remarks from userdata where status='requested'";
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            showdata();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            showdata();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string uid = (GridView1.Rows[e.RowIndex].FindControl("lbluid") as Label).Text;                   
            string stat = (GridView1.Rows[e.RowIndex].FindControl("ddlstatus") as DropDownList).SelectedValue;
            string remar = (GridView1.Rows[e.RowIndex].FindControl("eremarks") as TextBox).Text;
            string ins_qry = "update userdata set status=@status,remarks=@remarks where userid=@userid";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ins_qry;
             SqlParameter p1 = cmd.Parameters.Add("@userid", SqlDbType.VarChar, 20);
            p1.Value = uid;
          //  SqlParameter p2 = cmd.Parameters.Add("@street", SqlDbType.VarChar, 20);
          //  p2.Value = passwd;
            SqlParameter p3 = cmd.Parameters.Add("@status", SqlDbType.VarChar, 20);
            p3.Value = stat;
            SqlParameter p4 = cmd.Parameters.Add("@remarks", SqlDbType.VarChar, 20);
            p4.Value = remar;

            int total = cmd.ExecuteNonQuery();


            if (total == 1)
            {
                ClientScript.RegisterStartupScript(GetType(), "success", "<Script>alert('updated successfully')</Script>");
            }
            showdata();
        }
    }
}