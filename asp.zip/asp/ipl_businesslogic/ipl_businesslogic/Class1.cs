﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using ipl_classlib;

namespace ipl_businesslogic
{
    public class ipl_bl
    {
        public int insertdata(string team1, string team2, string result, string pom)
        {
            ipllib il = new ipllib();
            int i = il.insertmatch(team1, team2, result, pom);
            return i;
        }

        public DataSet ipl_show()
        {
            ipllib il1 = new ipllib();
            DataSet match = il1.showmatches();
            return match;
        }
        public DataSet ipl_team()
        {
            ipllib team = new ipllib();
            DataSet teams = team.showteams();
            return teams;
        }
        public int valid(string user, string password)
        {
            ipllib val = new ipllib();
            int i = val.validid(user, password);
            return i;
        }
        public int signup(string user, string pass)
        {
            ipllib sign = new ipllib();
            int i = sign.signup(user, pass);
            return i;
        }
    }
}
