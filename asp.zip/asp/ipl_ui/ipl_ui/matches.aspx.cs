﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ipl_businesslogic;

namespace ipl_ui
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ipl_bl bl = new ipl_bl();
            GridView1.DataSource = bl.ipl_show();
            GridView1.DataBind();
            
        }
    }
}