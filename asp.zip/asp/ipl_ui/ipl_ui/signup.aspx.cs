﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ipl_businesslogic;

namespace ipl_ui
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            string user;
            string password;
            user= TextBox1.Text ;
            password=TextBox2.Text;
            ipl_bl sign = new ipl_bl();
            int i = sign.signup(user, password);
            if (i > 0)
            {
                Label3.Visible = true;
            }
           

        }
    }
}