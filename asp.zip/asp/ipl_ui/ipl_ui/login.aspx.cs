﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ipl_businesslogic;

namespace ipl_ui
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_Click(object sender, EventArgs e)
        {
            string user;
            string password;
            ipl_bl validation = new ipl_bl();


            if (TextBox1.Text.Length == 0)
            {
                Label3.Visible = true;
            }
            if (TextBox2.Text.Length == 0)
            {
                Label4.Visible = true;
            }
            if ((TextBox1.Text.Length != 0) && (TextBox2.Text.Length != 0))
            {
                user = TextBox1.Text;
                password = TextBox2.Text;
                int i = validation.valid(user, password);
                if (i > 0)
                {
                    Response.Redirect("add.aspx");
                }
                else
                {
                    TextBox1.Text=string.Empty;
                    TextBox2.Text = string.Empty;
                    Label5.Visible = true;
                }
            }
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("signup.aspx");
        }
    }
}