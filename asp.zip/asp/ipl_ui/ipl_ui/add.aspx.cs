﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ipl_businesslogic;
using System.Data;

namespace ipl_ui
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            string team1;
            string team2;
            string result;
            string pom;

            team1 = TextBox1.Text;
            team2 = TextBox2.Text;
            result = TextBox3.Text;
            pom = TextBox4.Text;

            ipl_bl bl = new ipl_bl();
            int tot = bl.insertdata(team1, team2, result, pom);

            //Response.Write("Added successfully");
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            if (tot > 0)
            {
                Label5.Text = "Added Successfully";
            }
        }
    }
}